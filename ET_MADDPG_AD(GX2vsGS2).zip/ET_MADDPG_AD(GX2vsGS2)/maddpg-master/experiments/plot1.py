# -*- coding: utf-8 -*-
"""
Created on Tue Nov 16 10:56:29 2021

@author: zhao liran
"""
import pickle
#path='C:/Users/XxSunrise/Desktop/hahahah/maddpg-master/maddpg-master/experiments/benchmark_files/Xbench.pkl'  
#path='C:/Users/XxSunrise/Desktop/hahahah/maddpg-master/maddpg-master/experiments/learning_curves/Xbench_rewards.pkl'

path='E:/Deep Reinforcement learning/maddpg-master/experiments/learning_curves/None_agrewards.pkl'
f=open(path,'rb')
data=pickle.load(f)
 
print(data)
print(len(data))

  


