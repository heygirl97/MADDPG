#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 23 16:46:06 2024

@author: swarm
"""
import xlrd
import matplotlib.pyplot as plt
import numpy as np
import time
#import tensorflow.contrib.layers as layers



def plotguiji2(Date_Number,N,savetimes,file_name):
    exp_name=file_name
    xlsx = xlrd.open_workbook(file_name+'.xls')
    table = xlsx.sheet_by_index(0)
    # 获取agent1的dv 
    agent1px=[]
    agent1py=[]
    fig_size = (6*4, 4*4) 
    fig = plt.figure(figsize=fig_size)
    ax = fig.add_subplot(111, projection='3d')
    # plt.figure(1, figsize=(32, 20))#画第一个图

    for i in range(N,savetimes):
        agent1ax=[]
        agent1ay=[]
        agent1az=[]
        agent1ax0=[]
        agent1ay0=[]     
        agent1az0=[]   
        agent1_0 = [(table.cell_value(Date_Number[i][0]-1, m)) for m in range(0, 3)]
        agent1ax0.append(agent1_0[0])
        agent1ay0.append(agent1_0[1])
        agent1az0.append(agent1_0[2])
        agent2dx=[]
        agent2dy=[]
        agent2dz=[]
        agent2dx0=[]
        agent2dy0=[]        
        agent2dz0=[]    
        agent2_0 = [(table.cell_value(Date_Number[i][0]-1, m)) for m in range(3, 6)]
        agent2dx0.append(agent2_0[0])
        agent2dy0.append(agent2_0[1])
        agent2dz0.append(agent2_0[2])
        
        for j in range(Date_Number[i][0]-1,Date_Number[i][1]-1):
            agent1 = [(table.cell_value(j, m)) for m in range(0, 3)]
            agent1ax.append(agent1[0]/1000.0)
            agent1ay.append(agent1[1]/1000.0)
            agent1az.append(agent1[2]/1000.0)
        for l in range(Date_Number[i][0]-1,Date_Number[i][1]-1):
            agent2 = [(table.cell_value(l, m)) for m in range(3, 6)]
            agent2dx.append(agent2[0]/1000.0)
            agent2dy.append(agent2[1]/1000.0)
            agent2dz.append(agent2[2]/1000.0)
        
        if i==0:
            ax.plot(agent1ax, agent1ay, agent1az, c='r', marker='^', linestyle='--', label='Trajectory-A(DIvsDA)')
            ax.plot(agent2dx, agent2dy, agent2dz, c='b', marker='o', linestyle='--', label='Trajectory-D(DIvsBA)')
        if i==1:
            ax.plot(agent1ax, agent1ay, agent1az, c='r', marker='^', linestyle='--', label='Trajectory-A(DIvsBA)')
            ax.plot(agent2dx, agent2dy, agent2dz, c='b', marker='o', linestyle='--',label='Trajectory-D(DIvsBA)')
        if i==2:
            ax.plot(agent1ax, agent1ay, agent1az, c='r', marker='o', linestyle='--',label='Trajectory-A(CIvsDA)')
            ax.plot(agent2dx, agent2dy, agent2dz, c='b', marker='o', linestyle='--',label='Trajectory-D(CIvsDA)')

        if i==3:
            ax.plot(agent1ax, agent1ay, agent1az, c='r', marker='o', linestyle='--',label='Trajectory-A(CIvsBA)')
            ax.plot(agent2dx, agent2dy, agent2dz, c='b', marker='o', linestyle='--',label='Trajectory-D(CIvsBA)')
        
        
        if i==0:
            ax.scatter(agent1ax[-1], agent1ay[-1], agent1az[-1], c='r',s=200 ,marker='P', label='Final position of A (DIvsDA)')
            ax.scatter(agent2dx[-1], agent2dy[-1], agent2dz[-1], c='b',s=200, marker='P', label='Final position of D (DIvsDA)')
        if i==1:
            ax.scatter(agent1ax[-1], agent1ay[-1], agent1az[-1], c='r',s=200 ,marker='P', label='Final position of A (DIvsBA)')
            ax.scatter(agent2dx[-1], agent2dy[-1], agent2dz[-1], c='b',s=200, marker='P', label='Final position of D (DIvsBA)')
        if i==2:
            ax.scatter(agent1ax[-1], agent1ay[-1], agent1az[-1], c='r',s=200 ,marker='P', label='Final position of A (CIvsDA)')
            ax.scatter(agent2dx[-1], agent2dy[-1], agent2dz[-1], c='b',s=200, marker='P', label='Final position of D (CIvsDA)')
            
        if i==3:
            ax.scatter(agent1ax[-1], agent1ay[-1], agent1az[-1], c='r',s=200 ,marker='P', label='Final position of A (CIvsBA)')
            ax.scatter(agent2dx[-1], agent2dy[-1], agent2dz[-1], c='b',s=200, marker='P', label='Final position of D (CIvsBA)')
        
        
        # for i in range(len(agent1ax)):
        #     ax.text(agent1ax[i],agent1ay[i],agent1az[i],i)

    ax.scatter(agent1ax[0], agent1ay[0], agent1az[0], c='r',s=300 ,marker='*', label='Initial position of A')
    ax.scatter(agent2dx[0], agent2dy[0], agent2dz[0], c='b',s=300, marker='*', label='Initial position of D')    
    # 设置半径
    radius = 1
    # 指定起始和结束值，生成等间隔的经纬度序列
    longitude = np.linspace(0, 2 * np.pi, 200)
    latitude = np.linspace(0, np.pi, 200)

    # 计算向量间的外积
    x = radius * np.outer(np.cos(longitude), np.sin(latitude))
    y = radius * np.outer(np.sin(longitude), np.sin(latitude))
    z = radius * np.outer(np.ones(np.size(longitude)), np.cos(latitude))
    # 绘制球体
    ax.plot_surface(x, y, z, color='y', rstride=8, cstride=8, alpha=1.0)
        
    # 设置坐标轴字体大小
    plt.tick_params(axis='x', labelsize=18)  # 设置x轴的字体大小
    plt.tick_params(axis='y', labelsize=18)  # 设置y轴的字体大小
    plt.tick_params(axis='z', labelsize=18)  # 设置y轴的字体大小
        
    ax.set_xlabel('X(km)',fontsize=18)
    ax.set_ylabel('Y(km)',fontsize=18)
    ax.set_zlabel('Z(km)',fontsize=18)
    ax.set_aspect("equal")

    if i==0:
        ax.legend(prop={'size': 18},draggable=True,loc='center right') #'upper right'\'best'\'upper right'\'upper left'\'lower left'\'lower right'\'right'\'center left'\'center right'
    #'lower center'\'upper center'\'center'
        ax.view_init(elev=19, azim=-45)  # 设置视角，仰角为20度，方位角为45度
    
    if i==1:
        # ax.legend(prop={'size': 18},draggable=True,loc='upper center') #'upper right'
        ax.view_init(elev=29, azim=155)  # 设置视角，仰角为20度，方位角为45度
    
    if i==2:
        ax.legend(prop={'size': 18},draggable=True,loc='upper center') #'upper right'
        ax.view_init(elev=21, azim=-144)  # 设置视角，仰角为20度，方位角为45度

    if i==3:
        # ax.legend(prop={'size': 18},draggable=True,loc='center right') #'upper right'
        ax.view_init(elev=29, azim=-55)  # 设置视角，仰角为20度，方位角为45度
    plt.savefig(str(exp_name)+'figure'+str(i)+".png", dpi=300)
    plt.show()



Date_Number=[[3,22],[24,45],[47,68],[69,100]]
# Date_Number2=[[3,24],[27,41],[44,72]]
# Date_Number3=[[3,22],[25,41],[44,72]]
# Date_Number4=[[3,22],[25,41],[44,72]]
savetimes=2
file_name = "50-90-0-0"
plotguiji2(Date_Number,0,1,file_name)
plotguiji2(Date_Number,1,2,file_name)
plotguiji2(Date_Number,2,3,file_name)
plotguiji2(Date_Number,3,4,file_name)
# file_name2 = "45-0-90-90"
# plotguiji(Date_Number2,savetimes,file_name2)
# file_name3 = "45-0-135-180"
# plotguiji(Date_Number3,savetimes,file_name3)