import pickle
import matplotlib.pyplot as plt
import numpy as np
import xlwt


path1='/home/swarm/Algorithm/ET_MADDPG_AD(GX2vsGS2)/maddpg-master/experiments/learning_curves/GX3vsGS3-2_agrewards.pkl'  
path2='/home/swarm/Algorithm/ET_MADDPG_AD(GX2vsGS2)/maddpg-master/experiments/learning_curves/GX3vsGS3-2_rewards.pkl'  
path3='/home/swarm/Algorithm/ET_MADDPG_AD(GX2vsGS2)/maddpg-master/experiments/learning_curves/GX3vsGS3-2_cg.pkl'  
f1=open(path1,'rb')
f2=open(path2,'rb')
f3=open(path3,'rb')
data1=pickle.load(f1)
data2=pickle.load(f2)
date_number=len(data2)
data3=pickle.load(f3)
date_number3=len(data3)
p=[]
e=[]
D_success=[]
A_success=[]
F=[]
F2=[]
TF=[]
D_s=[]
#每100个点计算一次平局值(追)
for i in range(0,2*date_number):
    if i%2==0:
        p.append(data1[i])
    if i%2==1:       
        e.append(data1[i])
for i in range(0,date_number3):   
    D_success.append(data3[i][0]/1000.0)        
    A_success.append(data3[i][1]/1000.0) 
    F.append(data3[i][4]/1000.0) 
    F2.append((1000-data3[i][0]-data3[i][1]-data3[i][3]-data3[i][4])/1000.0) 
    TF.append(data3[i][3]/1000.0) 
    D_s.append(data3[i][0]/1000.0+data3[i][3]/1000.0) 

#plt.scatter(data)
book=xlwt.Workbook(encoding="utf-8")    #创建xls对象
worksheet=book.add_sheet("奖励变化")  #创建一个表单    
col=('进攻方奖励',"拦截方奖励")                   
for i in range(0,2):
    worksheet.write(0,i,col[i]) #列名
for i in range(0,100000):
    X=2*i
    if X+1>2*date_number:
        break
    for j in range(0,2):
        worksheet.write(i+1,j,data1[X+j])    
book.save("1k奖励变化(GXvsGS-2).xls")  #保存数据,注意必须使用xls对象操作，不能使用sheet表单操作保存    
print('储存奖励变化') 



book=xlwt.Workbook(encoding="utf-8")    #创建xls对象
worksheet=book.add_sheet("成功率变化")  #创建一个表单    
col=('拦截成功',"进攻成功","进攻者燃料耗尽","时间耗尽","任务终止","进攻成功率","拦截成功率")                   
for i in range(0,7):
    worksheet.write(0,i,col[i]) #列名
for i in range(0,date_number3):
    for j in range(0,7):
        worksheet.write(i+1,j,data3[i][j])    
book.save("博弈结果占比变化(GXvsGS-2).xls")  #保存数据,注意必须使用xls对象操作，不能使用sheet表单操作保存    
print('储存博弈结果占比变化') 






# plt.ion()#代开交互
plt.figure(1, figsize=(32, 20))#画第一个图
# Plot the actual value
plt.plot(data2, 'k-o', label = 'Main Reward',linewidth =4.0,markersize=10)
plt.plot(e,'b-*', label = 'defender',linewidth =4.0,markersize=10)
plt.plot(p, 'r-^', label = 'adversary',linewidth =4.0,markersize=10)
# plt.xticks(rotation = '500')
plt.legend(loc='best', prop = {'size':22})
# Graph labels
plt.xlabel('Episodes',fontsize=18)
plt.ylabel('Reward',fontsize=18)
plt.title('Reward',fontsize=18)
plt.tick_params(labelsize=18)
plt.show()
plt.savefig('reward.jpg')


plt.figure(2, figsize=(32, 20))#画第二个图
# Plot the actual value

plt.plot(D_success,'b', marker = 'h',label = 'D_success',linewidth =4.0,markersize=8)
plt.plot(A_success,'r',marker = 'd', label = 'A_success',linewidth =4.0,markersize=8)
plt.plot(F,'k-*', label = 'Task Termination1',linewidth =4.0,markersize=8)
plt.plot(F2,'y-o', label = 'Task Termination2',linewidth =4.0,markersize=8)
plt.plot(TF,'burlywood', marker = '^', label = 'Time Out',linewidth =4.0,markersize=8)
plt.legend(loc='best', prop = {'size':22})
# Graph labels
plt.xlabel('Episodes',fontsize=18)
plt.ylabel('Success Rate',fontsize=18)
plt.title('Success Rate',fontsize=18)
plt.tick_params(labelsize=18)
#plt.ioff() 
# #一定注意plot.ioff()一定在show()前面，不然就是一闪而过
plt.show()
plt.savefig('success.jpg')


plt.figure(3, figsize=(32, 20))#画第3个图
# Plot the actual value

plt.plot(D_s,'b', marker = 'h',label = 'D_success',linewidth =4.0,markersize=8)
plt.plot(A_success,'r',marker = 'd', label = 'A_success',linewidth =4.0,markersize=8)
plt.plot(F,'k-*', label = 'Task Termination1',linewidth =4.0,markersize=8)
plt.plot(F2,'y-o', label = 'Task Termination2',linewidth =4.0,markersize=8)
# plt.plot(TF,'burlywood', marker = '^', label = 'Time Out',linewidth =4.0,markersize=8)
plt.legend(loc='best', prop = {'size':22})
# Graph labels
plt.xlabel('Episodes',fontsize=18)
plt.ylabel('Success Rate',fontsize=18)
plt.title('Success Rate',fontsize=18)
plt.tick_params(labelsize=18)
#plt.ioff() 
# #一定注意plot.ioff()一定在show()前面，不然就是一闪而过
plt.show()
plt.savefig('success2.jpg')













