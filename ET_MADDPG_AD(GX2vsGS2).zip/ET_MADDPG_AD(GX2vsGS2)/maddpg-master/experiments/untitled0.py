# -*- coding: utf-8 -*-
"""
Created on Tue Nov 23 10:27:42 2021

@author: zhao liran
"""

import time
 
print "Start : %s" % time.time()
time.sleep( 5 )
print "End : %s" % time.time()
