# -*- coding: utf-8 -*-
"""
Created on Mon Dec  6 18:24:44 2021

@author: zhao liran
"""
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 21 17:37:13 2021

@author: zhao liran
"""
import numpy as np
import math
from math import sqrt, pow, acos, pi
from multiagent.core_satellite_PRD import World, Agent, Landmark
from multiagent.scenario import BaseScenario

class Scenario(BaseScenario):
    def make_world(self):
        world = World()
        #设置世界属性
        world.dim_c = 2
        num_target_agents = 1  #防御者数量
        num_good_agents = 1  #防御者数量
        num_adversaries = 1   #进攻者数量
        num_agents = num_adversaries +  num_good_agents + num_target_agents
        #障碍物数量
        num_landmarks = 0      
        #添加智能体
        world.agents = [Agent() for i in range(num_agents)]
        for i, agent in enumerate(world.agents):
            agent.name='agent %d' % i
            agent.collide = True
            agent.silent  = False
            if i < num_adversaries: #adversary 的定义（身份、距离、机动能力）
                agent.adversary = True
                agent.size = 500.0
                agent.accel = 3.0
                agent.fuel =600.0                
            else:
                agent.adversary = False
            if i > num_adversaries + num_good_agents -1:#target 的定义（身份、距离、机动能力）
                agent.target = True
                agent.size = 500.0
                agent.accel = 1.0
                agent.fuel =600.0   
            else:
                agent.target = False
            if i > num_adversaries-1 and i < num_adversaries + num_good_agents: #defender 的定义（身份、距离、机动能力）
                agent.defender = True
                agent.size = 500.0
                agent.accel = 2.0
                agent.fuel =600.0
            else:
                agent.defender = False      
        #添加障碍物
        world.landmarks = [Landmark() for i in range(num_landmarks)]
        for i, landmark in enumerate(world.landmarks):
            landmark.name = 'landmark %d' %i
            landmark.collide = True
            landmark.movable = False
            landmark.size = 0.1
            landmark.boundary = True
        #设置初始条件
        self.reset_world(world)
        return world



    def reset_world(self, world):
        #设置智能体的颜色
        for i, agent in enumerate(world.agents):
            agent.color = np.array([0.3,0.7,0.3]) if agent.adversary else  np.array([0.95,0.95,0.75])
        #设置地标的颜色
        for i, landmark in enumerate(world.landmarks):
            landmark.color = np.array([0.99,0.99,0.99])
        #设置随机初始状态
        for i, agent in enumerate(world.agents):
        #全随机分布下训练
            # theta=np.random.uniform(-1,1)
            # r= np.random.randint(+10000,+20000)
            # ax=r*math.cos(math.pi*theta)
            # ay=r*math.sin(math.pi*theta)  
            ax= np.random.randint(-200000,+200000)
            ay= np.random.randint(-200000,+200000)         
            tx= np.random.randint(-1000,+1000)
            ty= np.random.randint(-1000,+1000)       
            dx= np.random.randint(-50000,+50000)
            dy= np.random.randint(-50000,+50000)
            
            # theta_d = np.random.uniform(-1,1)            
            # rd = np.random.randint(+2000,+5000)
            # dx= rd*math.cos(math.pi*theta_d)
            # dy= rd*math.sin(math.pi*theta_d)
            if agent.adversary:
                agent.state.p_pos = np.array([ax+0.0,ay+0.0])
                agent.state.p_vel = np.array([0.0, 0.0])
            if agent.target:
                agent.state.p_pos = np.array([0.0, 0.0])
                agent.state.p_vel = np.array([0.0, 0.0])               
            if agent.defender:            
                agent.state.p_pos = np.array([dx+0.0, dy+0.0])
                agent.state.p_vel = np.array([0.0, 0.0])                


# #检测距离与成功率关系（追击固定距离圆上随机分布）
            # theta=np.random.uniform(-1,1)
            # r=80000
            # ax=r*math.cos(math.pi*theta)
            # ay=r*math.sin(math.pi*theta)      
            # agent.state.p_pos = np.array([ax,ay]) if agent.adversary else np.array([0.0, 0.0])
            
            # r=10000
            # theta= 0.0
            # ax=r*math.cos(math.pi*theta)
            # ay=r*math.sin(math.pi*theta)    
            # agent.state.p_pos = np.array([0.0,-10000.0]) if agent.adversary else np.array([0.0, -40000.0]) 
            
            
            # agent.state.p_vel = np.array([-1.0, 0.0])if agent.adversary else np.array([-14.02, 0.0])


            agent.state.c = np.zeros(world.dim_c)   #communication
            agent.state.fuel = 600.0
        for i, landmark in enumerate(world.landmarks):
            landmark.state.p_pos = np.array([0.0, 0.0])
            landmark.state.p_vel = np.array([0.0, 0.0])

     #碰撞计数    collision可以改为追击成功（更改函数，benchmark ， is_collision）
    # def benchmark_data(self, agent, world):
    #     # returns data for benchmarking purposes
    #     if agent.adversary:
    #         collisions = 0
    #         for a in self.good_agents(world):
    #             if self.is_collision(a, agent):
    #                 collisions += 1
    #         return collisions
    #     else:
    #         return 0
        #护卫拦截定义
    def is_collision(self, agent1, agent2):
        delta_pos = agent1.state.p_pos - agent2.state.p_pos
        dist = np.sqrt(np.sum(np.square(delta_pos)))
        dist_min = agent1.size + agent2.size
        return True if dist < dist_min else False

        #进攻成功定义
    def attract_success(self, agent, world):
        target = self.target(world)
        for tar in target:
            dist = np.sqrt(np.sum(np.square(agent.state.p_pos - tar.state.p_pos)))
            dist_min = 1000.0
        return True if dist <= dist_min else False



    # 护卫者集合
    def defenders(self, world):
        return [agent for agent in world.agents if agent.defender]

    # 进攻者集合
    def adversaries(self, world):
        return [agent for agent in world.agents if agent.adversary]

    # 进攻者集合
    def target(self, world):
        return [agent for agent in world.agents if agent.target]

    # 区分target\adversray\defender的reward
    def reward(self, agent, world):
        # Agents are rewarded based on minimum agent distance to each landmark
        if agent.adversary:
             main_reward = self.adversary_reward(agent, world)
        if agent.target:
             main_reward = self.target_reward(agent, world)
        if agent.defender:
             main_reward = self.defender_reward(agent, world)
        return main_reward
   #燃料消耗，消耗完为true 未消耗完为false 
    def agent_fuel(self, agent, world):
        if agent.state.fuel < 0:
            return True
        else:
            return False


    #target的reward设置
    def target_reward(self, agent, world):
        rew = 0.
        shape=True #True  False
        adversaries = self.adversaries(world)
        defenders = self.defenders(world)
        d_at=0.
        c_at=2000.
        if shape:
            for adv in adversaries:
                d_at = np.sqrt(np.sum(np.square(agent.state.p_pos - adv.state.p_pos)))
                rew -=  20*math.exp(-(d_at*d_at)/(2.0*c_at*c_at))
        if self.agent_fuel(agent,world):
            rew -= 10.0
        if agent.collide:
            for a in adversaries:
                if self.is_collision(a,agent):  
                    rew -= 5.0
                else:
                    rew += 1.0
                for d in defenders:
                    if self.is_collision(d,a):
                        rew += 50.0
        return rew 





    #defender的reward设置
    def defender_reward(self, agent, world):
        rew = 0.
        shape=True #True  False
        adversaries = self.adversaries(world)
        target = self.target(world) 
        r_da=[]
        r_dt=[]
        d=0.
        if shape:
            for adv in adversaries:
                d = np.sqrt(np.sum(np.square(agent.state.p_pos - adv.state.p_pos)))
                r_da =  adv.state.p_pos - agent.state.p_pos
                for t in target:
                     r_dt =  t.state.p_pos - agent.state.p_pos
            a=[r_da[0],r_da[1]]
            b=[r_dt[0],r_dt[1]]
            vector_prod = a[0] * b[0] + a[1] * b[1]
            length_prod = sqrt(pow(a[0], 2) + pow(a[1], 2)) * sqrt(pow(b[0], 2) + pow(b[1], 2))
            cos = vector_prod * 1.0 / (length_prod * 1.0+ 1e-8)
            rew += -0.0011*d #+ 0.01 * acos(cos)

        if self.agent_fuel(agent,world):
            rew -= 10.0
        if agent.collide:
            for a in adversaries:
                if self.is_collision(a,agent):  
                    rew += 50.0
                # if self.attract_success(a,world):
                #     rew -= 5.0
        return rew    

    



    #attacker者的reward设计 
    def adversary_reward(self, agent, world):
        rew = 0.
        d=0.
        a_ad=0.5
        c_ad=1500.0
        defenders = self.defenders(world)
        target = self.target(world)       
        adversaries = self.adversaries(world)
        D_ad = min([np.sqrt(np.sum(np.square(d.state.p_pos - agent.state.p_pos))) for d in defenders] )
        D_at = min(np.sqrt(np.sum(np.square(t.state.p_pos - agent.state.p_pos))) for t in target)
        rew += - 0.001*D_at #- a_ad*math.exp(-(D_ad*D_ad)/(2.0*c_ad*c_ad))
     
        if self.agent_fuel(agent,world):
            rew -= 10.0
        # if agent.collide:
        #     for de in defenders:
        #         for adv in adversaries:
        #             if self.is_collision(de,adv):
        #                 rew -= 20.0
        #             else:
        #                 rew -= 1.0
        if self.attract_success(agent,world):
            rew += 20.0
        return rew



    def observation(self, agent, world):
        # get positions of all entities in this agent's reference frame
        entity_pos = []
        for entity in world.landmarks:
            if not entity.boundary:
                entity_pos.append(entity.state.p_pos - agent.state.p_pos)
        # communication of all other agents
        comm = []
        other_pos = []
        other_vel = []
        for other in world.agents:
            if other is agent: continue
            comm.append(other.state.c)
            other_pos.append(other.state.p_pos - agent.state.p_pos)
            if not other.adversary:
                other_vel.append(other.state.p_vel)
        return np.concatenate([agent.state.p_vel] + [agent.state.p_pos] + entity_pos + other_pos + other_vel)
    
    def success_n(self,agent,world):
        defenders = self.defenders(world)
        adversaries = self.adversaries(world) 
        success_n = False
        for de in defenders:
            for adv in adversaries:
                if self.is_collision(de,adv):    
                    success_n = True
                    break
        return success_n     

    def success_attacker(self,agent,world):
        adversaries = self.adversaries(world) 
        success_attacker = False
        for adv in adversaries:
            if self.attract_success(adv, world):   
                success_attacker = True
        return success_attacker        


        #如果追击者燃料耗尽则认定任务结束，追击失败
    def fuel_n(self,agent,world):
        defenders = self.defenders(world)
        adversaries = self.adversaries(world)  
        for adv in adversaries:
            if self.agent_fuel(adv, world):
                fuel_n = True
                break
            else:          
                fuel_n = False

        return fuel_n
    
    def done_n(self, agent, world):
        done_n = False
#        if self.success_n(agent,world) or self.fuel_n(agent,world):
        if self.success_n(agent,world):
            done_n = True
        if self.success_attacker(agent,world):
            done_n = True
        return done_n
    
            

 

            
            
            
            
            
        


