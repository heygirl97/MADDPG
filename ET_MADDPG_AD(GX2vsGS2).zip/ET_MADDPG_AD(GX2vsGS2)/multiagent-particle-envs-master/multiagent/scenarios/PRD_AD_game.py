# -*- coding: utf-8 -*-
"""
Created on Mon Dec  6 18:24:44 2021

@author: zhao liran
"""
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 21 17:37:13 2021

@author: zhao liran
"""
import numpy as np
import math
from math import sqrt, pow, acos, pi
from multiagent.core_satellite_ode import World, Agent, Landmark
from multiagent.scenario import BaseScenario

class Scenario(BaseScenario):
    def make_world(self):
        world = World()
        #设置世界属性
        world.dim_c = 2
        num_good_agents = 1  #防御者数量
        num_adversaries = 1   #进攻者数量
        num_agents = num_adversaries +  num_good_agents
        #障碍物数量
        num_landmarks = 1     
        #添加智能体
        world.agents = [Agent() for i in range(num_agents)]
        for i, agent in enumerate(world.agents):
            agent.name='agent %d' % i
            agent.collide = True
            agent.silent  = False
            if i < num_adversaries: #adversary 的定义（身份、距离、机动能力）
                agent.adversary = True
                agent.size = 500.0
                agent.accel = 2.0
                agent.fuel =600.0                
            else:
                agent.adversary = False

            if i > num_adversaries-1 and i < (num_adversaries + num_good_agents): #defender 的定义（身份、距离、机动能力）
                agent.defender = True
                agent.size = 500.0
                agent.accel = 2.0 
                agent.fuel =600.0
            else:
                agent.defender = False      
        #添加障碍物
        world.landmarks = [Landmark() for i in range(num_landmarks)]
        for i, landmark in enumerate(world.landmarks):
            landmark.name = 'landmark %d' %i
            landmark.collide = True
            landmark.movable = False
            landmark.fuel =600.0
            landmark.size =1500.0
            landmark.target = True
        #设置初始条件
        self.reset_world(world)
        return world



    def reset_world(self, world):
        H=36000e3
        #引力常数(m3/s2)
        miu=39860044e+7 
        #地球半径
        R=6378137
        #参考航天器的平均角速度
        n= np.sqrt(miu/(H+R)**3)
        #设置智能体的颜色
        for i, agent in enumerate(world.agents):
            agent.color = np.array([0.3,0.7,0.3]) if agent.adversary else  np.array([0.95,0.95,0.75])
        #设置地标的颜色
        for i, landmark in enumerate(world.landmarks):
            landmark.color = np.array([0.99,0.99,0.99])

        #设置随机初始状态
        for i, agent in enumerate(world.agents):
        #全随机分布下训练
            theta1=np.random.uniform(-1.0,1.0)
            theta2=np.random.uniform(-1.0,1.0)
            r= np.random.randint(+50000,+60000) if agent.adversary else  np.random.randint(+10000,+20000)
            az=r*math.sin(math.pi*theta1)
            ax=r*math.cos(math.pi*theta1)*math.cos(math.pi*theta2)
            ay=r*math.cos(math.pi*theta1)*math.sin(math.pi*theta2)
            dz=r*math.sin(math.pi*theta1)
            dx=r*math.cos(math.pi*theta1)*math.cos(math.pi*theta2)
            dy=r*math.cos(math.pi*theta1)*math.sin(math.pi*theta2)
            # ax= np.random.randint(-50000,+50000)
            # ay= np.random.randint(-50000,+50000)    
            # az= np.random.randint(-10000,+10000) 
            # dx= np.random.randint(-20000,+20000)
            # dy= np.random.randint(-20000,+20000)
            # dz= np.random.randint(-10000,+10000) 
            # theta_d = np.random.uniform(-1,1)            
            # rd = np.random.randint(+2000,+5000)
            # dx= rd*math.cos(math.pi*theta_d)
            # dy= rd*math.sin(math.pi*theta_d)
            if agent.adversary:
                agent.state.p_pos = np.array([ax+0.0,ay+0.0,az+0.0])
                vy=-1.5*n*ax
                agent.state.p_vel = np.array([0.0, vy, 0.0])

            if agent.defender:            
                agent.state.p_pos = np.array([dx+0.0, dy+0.0, dz+0.0])
                vy=-1.5*n*dx
                agent.state.p_vel = np.array([0.0, vy, 0.0])   

            agent.state.c = np.zeros(world.dim_c)   #communication
            agent.state.fuel =600.0  
            
        for i, landmark in enumerate(world.landmarks):
            landmark.state.p_pos = np.array([0.0, 0.0, 0.0])
            landmark.state.p_vel = np.array([0.0, 0.0, 0.0])
            landmark.state.fuel =600.0
            landmark.target = True
# #检测距离与成功率关系（追击固定距离圆上随机分布）
            # theta=np.random.uniform(-1,1)
            # r=80000
            # ax=r*math.cos(math.pi*theta)
            # ay=r*math.sin(math.pi*theta)      
            # agent.state.p_pos = np.array([ax,ay]) if agent.adversary else np.array([0.0, 0.0])
            
            # r=10000
            # theta= 0.0
            # ax=r*math.cos(math.pi*theta)
            # ay=r*math.sin(math.pi*theta)    
            # agent.state.p_pos = np.array([0.0,-10000.0]) if agent.adversary else np.array([0.0, -40000.0]) 
            
            
            # agent.state.p_vel = np.array([-1.0, 0.0])if agent.adversary else np.array([-14.02, 0.0])





     #碰撞计数    collision可以改为追击成功（更改函数，benchmark ， is_collision）
    # def benchmark_data(self, agent, world):
    #     # returns data for benchmarking purposes
    #     if agent.adversary:
    #         collisions = 0
    #         for a in self.good_agents(world):
    #             if self.is_collision(a, agent):
    #                 collisions += 1
    #         return collisions
    #     else:
    #         return 0
        #护卫拦截定义
    def is_collision(self, agent1, agent2):
        delta_pos = agent1.state.p_pos - agent2.state.p_pos
        dist = np.sqrt(np.sum(np.square(delta_pos)))
        dist_min = agent1.size + agent2.size
        return True if dist < dist_min else False

        #进攻成功定义
    def attract_success(self, agent, world):
        target = self.target(world)
        for tar in target:
            dist = np.sqrt(np.sum(np.square(agent.state.p_pos - tar.state.p_pos)))
            dist_min = agent.size + tar.size
        return True if dist <= dist_min else False



    # 护卫者集合
    def defenders(self, world):
        return [agent for agent in world.agents if agent.defender]

    # 进攻者集合
    def adversaries(self, world):
        return [agent for agent in world.agents if agent.adversary]

    # 进攻者集合
    def target(self, world):
        return [landmark for landmark in world.landmarks if landmark.target]

    # 区分target\adversray\defender的reward
    def reward(self, agent, world):
        # Agents are rewarded based on minimum agent distance to each landmark
        if agent.adversary:
             main_reward = self.adversary_reward(agent, world)

        if agent.defender:
             main_reward = self.defender_reward(agent, world)
        return main_reward
   #燃料消耗，消耗完为true 未消耗完为false 
    def agent_fuel(self, agent, world):
        if agent.state.fuel < 0:
            return True
        else:
            return False





    #defender的reward设置
    def defender_reward(self, agent, world):
        rew = 0.
        shape=True #True  False
        adversaries = self.adversaries(world)
        target = self.target(world) 
        r_da=[]
        r_dt=[]
        d=0.
        N=np.random.uniform(-1,1)
        if shape:
            for adv in adversaries:
                d = np.sqrt(np.sum(np.square(agent.state.p_pos - adv.state.p_pos)))
                r_da =  adv.state.p_pos - agent.state.p_pos
                for t in target:
                     r_dt =  t.state.p_pos - agent.state.p_pos
            a=[r_da[0],r_da[1],r_da[2]]
            b=[r_dt[0],r_dt[1],r_dt[2]]
            vector_prod = a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
            length_prod = sqrt(pow(a[0], 2) + pow(a[1], 2)+ pow(a[2], 2)) * sqrt(pow(b[0], 2) + pow(b[1], 2)+ pow(b[2], 2))
            if length_prod==0:
                rew += -0.00011*d 
            else:
                cos = (vector_prod) / (length_prod)
                print(-0.00011*d,-math.pi + acos(cos))
                rew += -0.00011*d - (math.pi - acos(cos))

        if self.Fail(agent,world):
            rew -= 100.0
        if agent.collide:
            for a in adversaries:
                if self.is_collision(a,agent):  
                    rew += 200.0
                # if self.attract_success(a,world):
                #     rew -= 200.0
        return rew    

    



    #attacker者的reward设计 
    def adversary_reward(self, agent, world):
        rew = 0.
        d=0.
        a_ad=0.5
        c_ad=1500.0
        defenders = self.defenders(world)
        target = self.target(world)       
        adversaries = self.adversaries(world)
        D_ad = min([np.sqrt(np.sum(np.square(d.state.p_pos - agent.state.p_pos))) for d in defenders] )
        D_at = min(np.sqrt(np.sum(np.square(t.state.p_pos - agent.state.p_pos))) for t in target)
        rew += - 0.0001*D_at - a_ad*math.exp(-(D_ad*D_ad)/(2.0*c_ad*c_ad))
        print(- 0.0001*D_at,- a_ad*math.exp(-(D_ad*D_ad)/(2.0*c_ad*c_ad)))
     
        # if self.agent_fuel(agent,world):
        #     rew -= 10.0
        for de in defenders:
            for adv in adversaries:
                if self.is_collision(de,adv):
                    rew -= 100.0

        if self.attract_success(agent,world):
            rew += 200.0
        if self.Fail(agent, world):
            rew -= 300.0
        return rew



    def observation(self, agent, world):
        # get positions of all entities in this agent's reference frame
        entity_pos = []
        for entity in world.landmarks:
            entity_pos.append(entity.state.p_pos - agent.state.p_pos)
        entity_color = []
        for entity in world.landmarks:  # world.entities:
            entity_color.append(entity.color)
        # communication of all other agents
        comm = []
        other_pos = []
        for other in world.agents:
            if other is agent: continue
            comm.append(other.state.c)
            other_pos.append(other.state.p_pos - agent.state.p_pos)
        return np.concatenate([agent.state.p_vel] + entity_pos  + other_pos)

    
    def success_n(self,agent,world):
        defenders = self.defenders(world)
        adversaries = self.adversaries(world) 
        success_n = False
        for de in defenders:
            for adv in adversaries:
                if self.is_collision(de,adv):    
                    success_n = True
                    break
        return success_n     

    def success_attacker(self,agent,world):
        adversaries = self.adversaries(world) 
        success_attacker = False
        for adv in adversaries:
            if self.attract_success(adv, world):   
                success_attacker = True
        return success_attacker        

    def Fail(self,agent,world):
        defenders = self.defenders(world)
        adversaries = self.adversaries(world)
        target = self.target(world) 
        Fail=False
        for adv in adversaries:
            for t in target:
                D=np.sqrt(np.sum(np.square(adv.state.p_pos - t.state.p_pos)))
        if D>90000.0:
            Fail=True
        return Fail  
    
        #如果追击者燃料耗尽则认定任务结束，追击失败
    def fuel_n(self,agent,world):
        defenders = self.defenders(world)
        adversaries = self.adversaries(world)  
        for adv in adversaries:
            if self.agent_fuel(adv, world):
                fuel_n = True
                break
            else:          
                fuel_n = False

        return fuel_n
    
    def done_n(self, agent, world):
        done_n = False
#        if self.success_n(agent,world) or self.fuel_n(agent,world):
        if self.success_n(agent,world):
            done_n = True
        if self.success_attacker(agent,world):
            done_n = True
        if self.Fail(agent,world):
            done_n = True
        return done_n
    
            

 

            
            
            
            
            
        


