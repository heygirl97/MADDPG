# -*- coding: utf-8 -*-
"""
Created on Mon Dec  6 18:24:44 2021

@author: zhao liran
"""
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 21 17:37:13 2021

@author: zhao liran
"""
import numpy as np
from multiagent.core_satellite_PRD import World, Agent, Landmark
from multiagent.scenario import BaseScenario

class Scenario(BaseScenario):
    def make_world(self):
        world = World()
        #设置世界属性
        world.dim_c = 2
        num_good_agents = 1  #逃跑者数量
        num_adversaries = 1   #追击者数量
        num_agents = num_adversaries +  num_good_agents
        #障碍物数量
        num_landmarks = 0      
        #添加智能体
        world.agents = [Agent() for i in range(num_agents)]
        for i, agent in enumerate(world.agents):
            agent.name='agent %d' % i
            agent.collide = True
            agent.silent  = True
            agent.adversary = True if i < num_adversaries else False
            agent.size = 500.0 if agent.adversary else 500.0
            #agent.accel = np.array([0.4, 0.1 , 0.1]) if agent.adversary else np.array([0.2,0.05,0.05])
            agent.accel = 2.0 if agent.adversary else 1.0
            agent.fuel =40.0 if agent.adversary else 20.0
        #agent.max_speed = 0.5 if agent.adversary else 0.25       
        #添加障碍物
        world.landmarks = [Landmark() for i in range(num_landmarks)]
        for i, landmark in enumerate(world.landmarks):
            landmark.name = 'landmark %d' %i
            landmark.collide = True
            landmark.movable = False
            landmark.size = 0.1
            landmark.boundary = True
        #设置初始条件
        self.reset_world(world)
        return world
    
    
    
    def reset_world(self, world):
        #设置智能体的颜色
        for i, agent in enumerate(world.agents):
            agent.color = np.array([0.3,0.7,0.3]) if agent.adversary else  np.array([0.95,0.95,0.75])
        #设置地标的颜色
        for i, landmark in enumerate(world.landmarks):
            landmark.color = np.array([0.99,0.99,0.99])
            #world.landmarks[0].color = np.array([0.75,0.25,0.25])
        #设置随机初始状态
        for agent in world.agents:
            ax= np.random.randint(-10000,+10000)
            ay= np.random.randint(-10000,+10000)
            az= np.random.randint(-1,+1)
            #z= np.random.randint(-1000,+1000)
            
            bx= np.random.randint(-10000,+10000)
            by= np.random.randint(-10000,+10000)
            bz= np.random.randint(-1,+1)

            agent.state.p_pos = np.array([ax+1.0,ay+1.0, az+1.0]) if agent.adversary else np.array([bx+1.0, by+1.0, bz+1.0])
            agent.state.p_vel = np.array([0.0, 0.0, 0.0])if agent.adversary else np.array([0.0, 0.0, 0.0])
            #x= np.random.randint(-5000,+5000)
            #y= np.random.randint(-10000,+10000)
            #z= np.random.randint(-1000,+1000)
            #agent.state.p_pos = np.array([1000.+x,1000.+y, 0.+z]) if agent.adversary else np.random.uniform(-2000,+2000,world.dim_p)            
            #np.array([0.50, 0.50, 0.50])
            #agent.state.p_pos = np.random.uniform(-1,+1,world.dim_p)
            #agent.state.p_vel = np.zeros(world.dim_p)
            agent.state.c = np.zeros(world.dim_c)   #communication
            agent.state.fuel = 40.0 if agent.adversary else 20.0
        for i, landmark in enumerate(world.landmarks):
            landmark.state.p_pos = np.array([0.0, 0.0, 0.0])
            landmark.state.p_vel = np.array([0.0, 0.0, 0.0])   
            #landmark.state.p_pos = np.random.uniform(-1,+1,world.dim_p)
            #landmark.state.p_vel = np.zeros(world.dim_p)

        #碰撞计数    collision可以改为追击成功（更改函数，benchmark ， is_collision）
    def benchmark_data(self, agent, world):
        # returns data for benchmarking purposes
        if agent.adversary:
            collisions = 0
            for a in self.good_agents(world):
                if self.is_collision(a, agent):
                    collisions += 1
            return collisions
        else:
            return 0
        #碰撞定义
    def is_collision(self, agent1, agent2):
        delta_pos = agent1.state.p_pos - agent2.state.p_pos
        dist = np.sqrt(np.sum(np.square(delta_pos)))
        dist_min = agent1.size + agent2.size
        return True if dist < dist_min else False

    # 逃跑者集合
    def good_agents(self, world):
        return [agent for agent in world.agents if not agent.adversary]

    # 追击者集合
    def adversaries(self, world):
        return [agent for agent in world.agents if agent.adversary]

    # 区分追击者与逃跑者的reward
    def reward(self, agent, world):
        # Agents are rewarded based on minimum agent distance to each landmark
        main_reward = self.adversary_reward(agent, world) if agent.adversary else self.agent_reward(agent, world)
        return main_reward
#   #燃料消耗，消耗完为true 未消耗完为false 
    def agent_fuel(self, agent, world):
        if agent.state.fuel < 0:
            return True
        else:
            return False
        
        
        
        
        
        
        
    #逃跑者的reward设置
    def agent_reward(self, agent, world):
        #如果被抓住将会基于负面奖励
        rew = 0.
        shape=True #True  False
        adversaries = self.adversaries(world)
        p_force = [None]*2
        if shape:
            for adv in adversaries:
                rew += 0.001*np.sqrt(np.sum(np.square(agent.state.p_pos - adv.state.p_pos)))
        if self.agent_fuel(agent,world):
            rew -= 10.0
        if agent.collide:
            for a in adversaries:
                if self.is_collision(a,agent):  
                    rew -= 10.0
                else:
                    p_force = world.apply_action_force(p_force)
                    rew -= 0.1*(abs(p_force[1][0])+abs(p_force[1][1])+abs(p_force[1][2]))
                    rew += 1.0

        return rew    
    
    #追击者的reward设计 
    def adversary_reward(self, agent, world):
        rew = 0.
        agents = self.good_agents(world)
        adversaries = self.adversaries(world)
        p_force = [None]*2
        for adv in adversaries:
                rew -= 0.001*min([np.sqrt(np.sum(np.square(a.state.p_pos-adv.state.p_pos))) for a in agents] )
                if self.agent_fuel(adv,world):
                     rew -= 10.0
        if agent.collide:
            for ag in agents:
                for adv in adversaries:
                    if self.is_collision(ag,adv):
                        rew += 50.0
                    else:
                        p_force = world.apply_action_force(p_force)
                        rew -= 1.0 
                        rew -= 0.1*(abs(p_force[0][0])+abs(p_force[0][1])+abs(p_force[0][2]))
        return rew



    def observation(self, agent, world):
        # get positions of all entities in this agent's reference frame
        entity_pos = []
        for entity in world.landmarks:
            if not entity.boundary:
                entity_pos.append(entity.state.p_pos - agent.state.p_pos)
        # communication of all other agents
        comm = []
        other_pos = []
        other_vel = []
        for other in world.agents:
            if other is agent: continue
            comm.append(other.state.c)
            other_pos.append(other.state.p_pos - agent.state.p_pos)
#            #print('1:', other_pos )
            if not other.adversary:
                other_vel.append(other.state.p_vel)
#                print('2:', other_vel )
#        print('3:', np.concatenate([agent.state.p_vel] + [agent.state.p_pos] + entity_pos + other_pos + other_vel) )        
        return np.concatenate([agent.state.p_vel] + [agent.state.p_pos] + entity_pos + other_pos + other_vel)
    
    def success_n(self,agent,world):
        agents = self.good_agents(world)
        adversaries = self.adversaries(world) 
        for ag in agents:
            for adv in adversaries:
                if self.is_collision(ag,adv):    
                    success_n = True
                    break
                else:
                    success_n = False
        return success_n     
       
        #如果追击者燃料耗尽则认定任务结束，追击失败
    def fuel_n(self,agent,world):
        agents = self.good_agents(world)
        adversaries = self.adversaries(world)  
        for adv in adversaries:
            if self.agent_fuel(adv, world):
                fuel_n=True
                break
            else:          
                fuel_n = False

        return fuel_n
    
    def done_n(self, agent, world):
        if self.success_n(agent,world) or self.fuel_n(agent,world):
            done_n = True
        else:
            done_n = False
        return done_n
    
         
            
            
            
            
            
            
            
            
            
        


