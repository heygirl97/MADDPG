# -*- coding: utf-8 -*-
"""
Created on Tue Jun 14 17:31:59 2022

@author: Lenovo
"""
rew=0.
rew -= -0.1+0.1