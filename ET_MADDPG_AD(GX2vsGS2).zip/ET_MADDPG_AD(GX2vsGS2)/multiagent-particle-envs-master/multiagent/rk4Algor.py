# -*- coding: utf-8 -*-
"""
Created on Fri Dec  3 21:04:27 2021
t：时间变量   h：积分步长  N：系统阶数 y:状态向量 f：状态方程 
@author: zhao liran
"""


import numpy as np

def rk4Algor(t, h, N, y, f):
    k1=np.zeros(N); k2=np.zeros(N); k3=np.zeros(N); k4=np.zeros(N)
    k1 = h*f(t,y)                             
    k2 = h*f(t+h/2.,y+k1/2.)
    k3 = h*f(t+h/2.,y+k2/2.)
    k4 = h*f(t+h,y+k3)
    y=y+(k1+2*(k2+k3)+k4)/6.
    return y