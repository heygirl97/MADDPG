# -*- coding: utf-8 -*-
"""
Created on Tue Oct 26 15:29:51 2021
这里是首先对世界所具有的属性进行声明和初步赋值，之后在实际环境搭建过程中可以对其中属性的参数进行重新赋值
@author: zhao liran
"""
import numpy as np
from scipy.integrate import odeint
import math
from multiagent.solution import cal_quartic_ik
#所有个体（entites）的物理状态信息
class EntityState(object):
    def __init__(self):
        # physical position
        self.p_pos = None
        # physical velocity
        self.p_vel = None
        #燃料消耗
        self.fuel = None

# 智能体的状态state（包括通信）
class AgentState(EntityState):
    def __init__(self):
        super(AgentState, self).__init__()
        # communication utterance
        self.c = None

class Action(object):
    def __init__(self):
        #动作行为（控制）
        self.u = None
        #通信行为
        self.c = None

#物理世界实体的共有属性和状态
class Entity(object):
    def __init__(self):
        #name
        self.name = ''
        #属性
        self.size = 0.030
        #是否可移动
        self.movable = False 
        #是否会发生碰撞
        self.collide = True
        #密度 影响质量
        self.density = 25.0
        #颜色
        self.color = None
        #最大速度和加速度
        self.max_speed = None
        self.accel = None
        #状态(调用前面声明的EntityState)
        self.state = EntityState()
        #质量
        self.initial_mass = 1.0

    @property        #函数装饰器中的一种，将函数变为只读（不可随意更改）性质
    def mass(self):
        return self.initial_mass

#障碍物的属性声明   
class Landmark(Entity):
    def __init__(self):
        super(Landmark,self).__init__()

#智能体的属性声明与定义
class  Agent(Entity):
    def __init__(self):
        super(Agent, self).__init__()                #super函数作用为调用父类，本例中父类为Entity
        #默认状态下智能体是可移动的
        self.movable = True
        #是否静默（无通信）
        self.silent = False
        #观测能力
        self.blind = False
        #物理执行器的噪声
        self.u_noise = False
        #通信噪声
        self.c_noise = None
        #控制上界
        self.u_range = 1.0
        #状态
        self.state = AgentState()
        #动作
        self.action = Action()
        #要执行的脚本行为
        self.action_callback = None


        
#多智能体世界声明
class World(object):
    def __init__(self):
        #智能体和实体的列表
        self.agents=[]
        self.landmarks=[]
        #通信渠道的维度
        self.dim_c = 0
        #位置状态维度
        self.dim_p = 3
        #颜色维度
        self.dim_color = 3
        #决策点时间间隔
        self.dT=600     
        #环境阻力
        self.damping = 0.0

        self.H=36000e3
        #引力常数(m3/s2)
        self.miu=39860044e+7 
        #地球半径
        self.R=6378137.0
        #参考航天器的平均角速度
        self.n= np.sqrt(self.miu/(self.H+self.R)**3)    
#整合环境中所有的实体(智能体+障碍物),转为只读性质
    @property
    def entities(self):
        return self.agents + self.landmarks

#整合所有由外部控制策略控制的智能体
    @property
    def policy_agents(self):
        return [agent for agent in self.agents if agent.action_callback is None]
    
#返回所有由世界脚本控制的智能体
    @property
    def scripted_agents(self):
        return [agent for agent in self.agents if agent.action_callback is not None]

    def rendezvous_detection(self):
        n=self.n
        x0=[None]*len(self.entities)
        y0=[None]*len(self.entities)
        z0=[None]*len(self.entities)
        dx0=[None]*len(self.entities)
        dy0=[None]*len(self.entities)
        dz0=[None]*len(self.entities)
        size=[None]*len(self.entities)
        T=None
        # 0-adversary 1-defender 2-target
        for i,entity in enumerate(self.entities):                
            x0[i]  = entity.state.p_pos[0]
            y0[i]  = entity.state.p_pos[1]
            z0[i]  = entity.state.p_pos[2]            

            dx0[i]  = entity.state.p_vel[0]
            dy0[i]  = entity.state.p_vel[1]
            dz0[i]  = entity.state.p_vel[2]  
            size[i] = entity.size
        # e(adversary-defender)0-1
        e_ad_x= x0[0] - x0[1]
        e_ad_y= y0[0] - y0[1]
        e_ad_z= z0[0] - z0[1]
        e_ad_dx = dx0[0] - dx0[1]
        e_ad_dy = dy0[0] - dy0[1]
        e_ad_dz = dz0[0] - dz0[1]  
        D_max_ad = size[0] + size[1] -1
        t_ad=self.solution(e_ad_x,e_ad_y,e_ad_z,e_ad_dx,e_ad_dy,e_ad_dz, D_max_ad,n)
        
        # e(adversary-target)0-2
        e_at_x=x0[0] - x0[2]
        e_at_y=y0[0] - y0[2]
        e_at_z=z0[0] - z0[2]
        e_at_dx=dx0[0] - dx0[2]
        e_at_dy=dy0[0] - dy0[2]
        e_at_dz=dz0[0] - dz0[2]  
        D_max_at = size[0] + size[2] -1
        t_at=self.solution(e_at_x,e_at_y,e_at_z,e_at_dx,e_at_dy,e_at_dz, D_max_at,n)  
        T = min(t_ad,t_at)
        return T
    
    
    def solution(self,e_x,e_y,e_z,e_dx,e_dy,e_dz,D_max,n):
        t1=t2=t3=t4=None
        A= (e_dx/n)**2 + (4*e_dy/n+ 6*e_x)**2 + (e_dz/n)**2
        B= (3*e_x+2*e_dy/n)**2 + (2*e_dx/n)**2 + e_z**2
        C= -2*e_dx/n*(3*e_x+2*e_dy/n)+8*(2/n*e_dy+3*e_x)*e_dx/n+2*e_dz*e_z/n
        D= 4*e_dx/n*(2*e_x+e_dy/n)+4*(2/n*e_dy+3*e_x)*(e_y-2*e_dx/n)
        E= -4*(3*e_x+2*e_dy/n)*(2*e_x+e_dy/n)+4*e_dx*(e_y-2*e_dx/n)/n
        F= -12*(2/n*e_dy+3*e_x)*(e_dy+2*n*e_x)
        G= -12*e_dx/n*(e_dy+2*n*e_x)
        H= 9*(e_dy+2*n*e_x)**2
        I= -6*(e_dy+2*n*e_x)*(e_y-2*e_dx/n)
        J= (4*e_x+2*e_dy/n)**2 + (e_y-2*e_dx/n)**2
        a = 1/3*(B-A+1/8*E)*(n**4.0)-F*(n**3.0)/6.0
        b = -(4.0*C+D)*(n**3.0)/6-G*(n**2.0)/2.0
        c = (A-B-0.5*E)*(n**2.0)+F*n+H
        d = C*n+D*n+G+I
        e = B + E + J - D_max**2.0
        args_list=a,b,c,d,e       
        s,S=cal_quartic_ik(args_list)
        t=self.dT
        if s!=0:
            for i in range(s):
                if  0.0 <= S[i] <= self.dT and S[i] < t:
                        t=S[i]
        return t
                
                
                
                
#更新决策点状态
    def step1(self):
        #作用在实体(entities)上的作用力
        p_force = [None]*len(self.entities)
        #作用在智能体上的控制力
        p_force = self.apply_action_force(p_force)
        
        #整合智能力的物理状态
        self.integrate_state(p_force)
        # 积分无控下dT时间内状态的变化
                    
        #更新智能体的通信 (感觉这里有问题)
        for agent in self.agents:
            self.update_agent_state(agent)                    


            
    #整合智能体的控制力
    def apply_action_force(self, p_force):
        #设置施加的力
        for i,agent in enumerate(self.agents):
            if agent.movable:
                noise = np.random.randn(*agent.action.u.shape)*agent.u_noise if agent.u_noise else 0.0
                p_force[i] = agent.action.u + noise
        return p_force
    
    #相对运动学方程
    def CW(self,y,t):
        '''
        ODE in x,y,z direction
        '''
        dy = [0.0,0.0,0.0,0.0,0.0,0.0]
        miu  = self.miu
        R    = self.H+self.R
    # 计算主星的轨道角速度(rad/s)
        n = self.n
        dy[0] = y[3]
        dy[1] = y[4]
        dy[2] = y[5]
        dy[3] = 2*n*y[4]+ n**2*y[0]- miu*(R+y[0])/(( (R+y[0])**2 + y[1]**2 + y[2]**2 )**1.5) + miu/(R**2)
        dy[4] = -2*n*y[3]+ n**2*y[1]- miu*y[1] /(( (R+y[0])**2 + y[1]**2 + y[2]**2 )**1.5 )
        dy[5] = - miu*y[2] /(( (R+y[0])**2 + y[1]**2 + y[2]**2 )**1.5 )
                     
        return [dy[0], dy[1],dy[2], dy[3],dy[4], dy[5]]  
    
    #对状态求积分，更新状态
    def integrate_state(self, p_force):
        for i,entity in enumerate(self.entities):
            if entity.state.fuel <0.0:
                p_force[i]=None

            #判断是否收到外力，并计算v
            if (p_force[i] is not None):
                #状态改变
                entity.state.p_vel[0] += p_force[i][0]
                entity.state.p_vel[1] += p_force[i][1]
                entity.state.p_vel[2] += p_force[i][2]
                entity.state.fuel  -= abs(p_force[i][0])+abs(p_force[i][1])+abs(p_force[i][2])
            else:
                print(entity.state.p_pos)
        DT = self.rendezvous_detection()
        # if DT < self.dT:
        #     print('DT',DT)
        for i,entity in enumerate(self.entities):
            
            x0 = entity.state.p_pos[0]
            y0 = entity.state.p_pos[1]
            z0 = entity.state.p_pos[2]            
            dx0= entity.state.p_vel[0]
            dy0= entity.state.p_vel[1]
            dz0= entity.state.p_vel[2]
            pos_0 = [x0,y0,z0,dx0,dy0,dz0]
            t = np.linspace(0,DT,2)
            z = odeint(self.CW, pos_0, t)
            entity.state.p_pos[0] = z[-1,0]
            entity.state.p_pos[1] = z[-1,1]
            entity.state.p_pos[2] = z[-1,2]
            entity.state.p_vel[0] = z[-1,3]
            entity.state.p_vel[1] = z[-1,4]
            entity.state.p_vel[2] = z[-1,5]


        
        #通信设置
    def update_agent_state(self, agent): 
    # set communication state (directly for now)
        if agent.silent:
            agent.state.c = np.zeros(self.dim_c)
        else:
            noise = np.random.randn(*agent.action.c.shape) * agent.c_noise if agent.c_noise else 0.0
            agent.state.c = agent.action.c + noise      
             
    
        
      
        
        
        
        