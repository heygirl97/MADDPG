import gym
from gym import spaces
from gym.envs.registration import EnvSpec
import numpy as np
from multiagent.multi_discrete import MultiDiscrete

# environment for all agents in the multiagent world
# currently code assumes that no agents will be created/destroyed at runtime!
class MultiAgentEnv(gym.Env):
    metadata = {
        'render.modes' : ['human', 'rgb_array']
    }

    def __init__(self, world, agent_fuel_callback=None,reset_callback=None, reward_callback=None,
                 observation_callback=None, done_callback=None, success_callback=None , Fail_callback=None ,success_attacker_callback=None, info_callback=None,
                  shared_viewer=True):

        self.world = world
        self.agents = self.world.policy_agents
        # set required vectorized gym env property
        self.n = len(world.policy_agents)
        # scenario callbacks
        self.reset_callback = reset_callback
        self.agent_fuel_callback = agent_fuel_callback
        self.reward_callback = reward_callback
        self.observation_callback = observation_callback
        self.info_callback = info_callback
        self.done_callback = done_callback
        self.success_callback = success_callback
        self.Fail_callback = Fail_callback
        self.success_attacker_callback = success_attacker_callback
        # environment parameters
        self.discrete_action_space = True#True  False
        # if true, action is a number 0...N, otherwise action is a one-hot N-dimensional vector
        self.discrete_action_input = False
        # if true, even the action is continuous, action will be performed discretely
        self.force_discrete_action = world.discrete_action if hasattr(world, 'discrete_action') else False
        # if true, every agent has the same reward
        self.shared_reward = world.collaborative if hasattr(world, 'collaborative') else False
        self.time = 0
        self.lameda=0.1

        # configure spaces
        self.action_space = []
        self.observation_space = []
        for agent in self.agents:
            total_action_space = []  #包含了动作控制空间u_action_space与通信控制空间c_action_space
            # physical action space
            if self.discrete_action_space:
                u_action_space = spaces.Discrete(world.dim_p * 2 + 1) # Set with (world.dim_p * 2 + 1) elements {0, 1, 2, ..., 6}
            else:
                u_action_space = spaces.Box(-agent.u_range, +agent.u_range, [world.dim_p], dtype=np.float32)   
            if agent.movable:
                total_action_space.append(u_action_space)

            # communication action space
            if self.discrete_action_space:
                c_action_space = spaces.Discrete(world.dim_c)

            else:
                c_action_space = spaces.Box(low=0.0, high=1.0, shape=(world.dim_c,), dtype=np.float32)
            if not agent.silent:
                total_action_space.append(c_action_space)

            # total action space 高维动作空间的将Discrete类变为multi discrete类
            if len(total_action_space) > 1:
                # all action spaces are discrete, so simplify to MultiDiscrete action space  isinstance（a,b）函数判断a是否属于b的属性
                if all([isinstance(act_space, spaces.Discrete) for act_space in total_action_space]):
                    act_space = MultiDiscrete([[0, act_space.n - 1] for act_space in total_action_space])
                    #print(act_space.sample())
                else:
                    act_space = spaces.Tuple(total_action_space)

                self.action_space.append(act_space)
            else:
                self.action_space.append(total_action_space[0])
            # observation space
            obs_dim = len(observation_callback(agent, self.world))
            self.observation_space.append(spaces.Box(low=-10000000, high=+10000000, shape=(obs_dim,), dtype=np.float32))
            agent.action.c = np.zeros(self.world.dim_c)

        # rendering
        self.shared_viewer = shared_viewer
        if self.shared_viewer:
            self.viewers = [None]
        else:
            self.viewers = [None] * self.n
        self._reset_render()


    def step(self, action_n, test_step, savestate,agent1pos,agent1v,dv1,agent2pos,agent2v,dv2,date_number):
        obs_n = []
        reward_n = []
        done_n = []
        info_n = {'n': []}
        test_i=1
        self.agents = self.world.policy_agents
        rew=[]
        done_test = []
        agent_fuel= []
        success_test = []
        Fail_test = []
        success_attacker=[]
        test_t=0
        # set action for each agent(选择控制量)
        for i, agent in enumerate(self.agents):
            self._set_action(action_n[i], agent, self.action_space[i])
        #决策点状态改变    
        self.world.step1()
        #储存轨迹
        if savestate:  
            for i, agent in enumerate(self.agents):
                if i == 0 :
                    agent1pos.append(self.agents[i].state.p_pos.tolist())
                    agent1v.append(self.agents[i].state.p_vel.tolist())
                    dv1.append(self.agents[i].action.u.tolist())
                if i == 1 :
                    agent2pos.append(self.agents[i].state.p_pos.tolist())
                    agent2v.append(self.agents[i].state.p_vel.tolist())    
                    dv2.append(self.agents[i].action.u.tolist())
            date_number +=1 
            
        
        #计算rew并判定是否done
        for i, agent in enumerate(self.agents):
            rew.append(self._get_reward(agent))    
            done_test.append(self._get_done(agent))
            agent_fuel.append(self._get_agent_fuel_callback(agent))
            success_test.append(self._get_success(agent))
            Fail_test.append(self._get_Fail(agent))  
            success_attacker.append(self._get_success_attacker(agent))  
        done_t = any(done_test)
        fuel_done = any(agent_fuel)
        success_t = any(success_test)
        Fail_t = any(Fail_test)
        Success_Attacker = any(success_attacker)
        #done_t为真则任务结束，返回信息
        if done_t :
            for agent in self.agents:
                obs_n.append(self._get_obs(agent))
                done_n.append(self._get_done(agent))
                info_n['n'].append(self._get_info(agent))
                    # all agents get total reward in cooperative case
            reward_n=rew
            return obs_n, reward_n, done_n, info_n , fuel_done, success_t, Fail_t,Success_Attacker, test_t ,agent1pos,agent1v,dv1,agent2pos,agent2v,dv2,date_number       
        #done_t为假则继续计算预测检测点的状态信息，直到某个监测点的done_t为真或者计算完该阶段所有的检测点信息
        else:                                            
            while test_i<test_step:
                done_test = []
                success_test = []
                Fail_test = []
                #计算无控状态下的状态转移                
                self.world.step2()
                
                
                #储存轨迹
                if savestate and test_i<(test_step-1):  
                    for i, agent in enumerate(self.agents):
                        if i == 0 :
                            agent1pos.append(self.agents[i].state.p_pos.tolist())
                            agent1v.append(self.agents[i].state.p_vel.tolist())
                            dv1.append(self.agents[i].action.u.tolist())
                        if i == 1 :
                            agent2pos.append(self.agents[i].state.p_pos.tolist())
                            agent2v.append(self.agents[i].state.p_vel.tolist())  
                            dv2.append(self.agents[i].action.u.tolist())
                    date_number +=1                 
                
                
                
                #计算rew并判定是否done
                for i, agent in enumerate(self.agents):
                    #rew_test_t(i)=rew_test_t(i-1)*lameda+reward_t(i)
                    rew_test=self._get_reward(agent)
                    rew[i]=rew[i]*self.lameda+rew_test
                    #rew.append(self._get_reward(agent))
                    done_test.append(self._get_done(agent))
                    success_test.append(self._get_success(agent))
                    Fail_test.append(self._get_Fail(agent)) 
                    success_attacker.append(self._get_success_attacker(agent)) 
                
                done_t = any(done_test)
                success_t = any(success_test)
                test_t=test_i
                Fail_t = any(Fail_test)
                Success_Attacker = any(success_attacker)
                
                if done_t:
                    break
                else:
                    test_i=test_i+1
        
        

        
        # record observation for each agent
            for agent in self.agents:
                obs_n.append(self._get_obs(agent))
                #reward_n.append(self._get_reward(agent))
                done_n.append(self._get_done(agent))
                info_n['n'].append(self._get_info(agent))
                # all agents get total reward in cooperative case
            reward_n=rew
            return obs_n, reward_n, done_n, info_n, fuel_done , success_t, Fail_t,Success_Attacker, test_t ,agent1pos,agent1v,dv1,agent2pos,agent2v,dv2,date_number     

    def reset(self):
        # reset world
        self.reset_callback(self.world)
        # reset renderer
        self._reset_render()
        # record observations for each agent
        obs_n = []
        self.agents = self.world.policy_agents
        for agent in self.agents:
            obs_n.append(self._get_obs(agent))
        return obs_n

    # get info used for benchmarking
    def _get_info(self, agent):
        if self.info_callback is None:
            return {}
        return self.info_callback(agent, self.world)

    # get observation for a particular agent
    def _get_obs(self, agent):
        if self.observation_callback is None:
            return np.zeros(0)
        return self.observation_callback(agent, self.world)

    # get dones for a particular agent
    # unused right now -- agents are allowed to go beyond the viewing screen
    def _get_done(self, agent):
        if self.done_callback is None:
            return False
        return self.done_callback(agent, self.world)
    
    def _get_agent_fuel_callback(self, agent):
        if self.agent_fuel_callback is None:
            return False
        return self.agent_fuel_callback(agent, self.world)
    
    
    def _get_success(self, agent):
        if self.success_callback is None:
            return False
        return self.success_callback(agent, self.world)
    
    def _get_Fail(self, agent):
        if self.Fail_callback is None:
            return False
        return self.Fail_callback(agent, self.world)    
    
    def _get_success_attacker(self, agent):
        if self.success_attacker_callback is None:
            return False
        return self.success_attacker_callback(agent, self.world) 
    
    # get reward for a particular agent
    def _get_reward(self, agent):
        if self.reward_callback is None:
            return 0.0
        return self.reward_callback(agent, self.world)

    # 设置智能力的控制集合
    def _set_action(self, action, agent, action_space, time=None):
        agent.action.u = np.zeros(self.world.dim_p)
        agent.action.c = np.zeros(self.world.dim_c)
        # process action
        if isinstance(action_space, MultiDiscrete):
            act = []
            size = action_space.high - action_space.low + 1
            index = 0
            for s in size:
                act.append(action[index:(index+s)])
                index += s
            action = act
        else:
            action = [action]


        if agent.movable:
            # physical action
            if self.discrete_action_input:
                agent.action.u = np.zeros(self.world.dim_p)
                # process discrete action
                if action[0] == 1: agent.action.u[0] = -1.0
                if action[0] == 2: agent.action.u[0] = +1.0
                if action[0] == 3: agent.action.u[1] = -1.0
                if action[0] == 4: agent.action.u[1] = +1.0
            else:
                if self.force_discrete_action:
                    d = np.argmax(action[0])
                    action[0][:] = 0.0
                    action[0][d] = 1.0
                if self.discrete_action_space:
                    agent.action.u[0] += action[0][1] - action[0][2]
                    agent.action.u[1] += action[0][3] - action[0][4]
                    agent.action.u[2] += action[0][5] - action[0][6]       #三维

                else:
                    agent.action.u = action[0]
            sensitivity = 1  #灵敏度——加速度
            if agent.accel is not None:
                sensitivity = agent.accel
            agent.action.u *= sensitivity

            action = action[1:]
            
        if not agent.silent:
            # communication action
            if self.discrete_action_input:
                agent.action.c = np.zeros(self.world.dim_c)
                agent.action.c[action[0]] = 1.0
            else:
                agent.action.c = action[0]
            action = action[1:]
        # make sure we used all elements of action
        assert len(action) == 0

    # reset rendering assets
    def _reset_render(self):
        self.render_geoms = None
        self.render_geoms_xform = None



# vectorized wrapper for a batch of multi-agent environments
# assumes all environments have the same observation and action space
class BatchMultiAgentEnv(gym.Env):
    metadata = {
        'runtime.vectorized': True,
        'render.modes' : ['human', 'rgb_array']
    }

    def __init__(self, env_batch):
        self.env_batch = env_batch

    @property
    def n(self):
        return np.sum([env.n for env in self.env_batch])

    @property
    def action_space(self):
        return self.env_batch[0].action_space

    @property
    def observation_space(self):
        return self.env_batch[0].observation_space

    def step(self, action_n, time):
        obs_n = []
        reward_n = []
        done_n = []
        info_n = {'n': []}
        i = 0
        for env in self.env_batch:
            obs, reward, done, _ = env.step(action_n[i:(i+env.n)], time)
            i += env.n
            obs_n += obs
            # reward = [r / len(self.env_batch) for r in reward]
            reward_n += reward
            done_n += done
        return obs_n, reward_n, done_n, info_n

    def reset(self):
        obs_n = []
        for env in self.env_batch:
            obs_n += env.reset()
        return obs_n

    # render environment
    def render(self, mode='human', close=True):
        results_n = []
        for env in self.env_batch:
            results_n += env.render(mode, close)
        return results_n
