# -*- coding: utf-8 -*-
"""
Created on Mon Dec  6 16:53:46 2021

@author: zhao liran
"""
import numpy as np
x= np.random.randint(-1000,+1000)
y= np.random.randint(-1000,+1000)
z= np.random.randint(-1000,+1000)
a=np.array([0.+x, y, z])
b=np.random.uniform(-2000,+2000,1)
c=np.append(b,np.random.uniform(-2000,+2000,1))